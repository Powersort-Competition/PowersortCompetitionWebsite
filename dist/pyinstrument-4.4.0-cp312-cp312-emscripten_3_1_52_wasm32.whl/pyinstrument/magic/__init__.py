from .magic import PyinstrumentMagic
