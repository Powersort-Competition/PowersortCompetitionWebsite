
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.5.0'
version = '1.5.0'
full_version = '1.5.0.dev0+Unknown.Unknown'
git_revision = 'Unknown'
commit_count = 'Unknown'
release = False
if not release:
    version = full_version
