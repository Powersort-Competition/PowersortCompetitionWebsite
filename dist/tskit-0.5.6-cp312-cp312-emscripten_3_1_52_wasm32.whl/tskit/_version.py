# Definitive location for the version number.
# During development, should be x.y.z.devN
# For beta should be x.y.zbN
tskit_version = "0.5.6"
