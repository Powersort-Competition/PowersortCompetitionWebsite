# License: BSD-3-Clause
# Copyright the MNE-Python contributors.
from pathlib import Path

data_dir = Path(__file__).parent / "data"
